package stockrmiproject;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;

/**
 * A RMI server side servant providing the functions used in server side operations
 * 
 * @author Gao
 */
public class StockRMIServant extends UnicastRemoteObject implements StockRMI {
    
    /**
     * stocks -  TreeMap storing the stocks and the interested users of each stock
     */
    private static TreeMap<String, ArrayList<String>> stocks;
    /**
     * stockPrices - TreeMap storing the stocks and the corresponding prices
     */
    private static TreeMap<String, Double> stockPrices;
    /**
     * users - TreeMap storing the users and corresponding remote client Notifiable object
     */
    private static TreeMap<String, Notifiable> users;
    
    // initialize the static variables in the server
    static {
        stocks = new TreeMap<>();
        stockPrices = new TreeMap<>();
        users = new TreeMap<>();
        
        stockPrices.put("IBM", 102.00);
        stockPrices.put("USX", 238.45);
        stockPrices.put("MIC", 654.99);
        
        ArrayList<String> IBMUserList = new ArrayList<String>();
        ArrayList<String> USXUserList = new ArrayList<String>();
        ArrayList<String> MICUserList = new ArrayList<String>();
        
        stocks.put("IBM", IBMUserList);
        stocks.put("USX", USXUserList);
        stocks.put("MIC", MICUserList);
               
    }
    
    public StockRMIServant() throws RemoteException { 
    }
    

    /**
     * subscribe - subscribe a user to a given stock
     * 
     * @param user user name of the interested user
     * @param stockSym stock name of the target stock
     * 
     * @return true - if subscribe successfully
     *         false - if the stock doesn't exist
     * 
     * @throws RemoteException 
     */
    @Override
    public boolean subscribe(String user, String stockSym) throws RemoteException {
        
        if (stocks.containsKey(stockSym)) {
            
            ArrayList<String> userList = stocks.get(stockSym);
            
            // if the user is already in the list
            if (userList.contains(user)) {
                return true;
            }
            
            userList.add(user);
            stocks.put(stockSym, userList);
            return true;
            
        } else {
            
            // if the stock doesn't exist
            System.out.println("Wrong stockSym.");
            return false;
            
        }
   
    }

    /**
     * unSubscribe - remove a user from the subscribing list of a stock 
     * 
     * @param user user name of the uninterested user
     * @param stockSym stock name of the target stock
     * 
     * @return true - if remove successfully
     *         false - if the stock is not existed
     * @throws RemoteException 
     */
    @Override
    public boolean unSubscribe(String user, String stockSym) throws RemoteException {
        
        if (stocks.containsKey(stockSym)) {
            
            ArrayList<String> userList = stocks.get(stockSym);
            
            // update the related user list for the stock
            userList.remove(user);
            stocks.put(stockSym, userList);
            return true;

        } else {
            
            System.out.println("Wrong stockSym.");
            return false;
            
        }
       
    }

    /**
     * stockUpdate - update the price for a stock provided by the dealer and notify the clients who are interested in the stock
     *  
     * @param stockSym stock to be updated
     * @param price new price for updating
     * 
     * @throws RemoteException 
     */
    @Override
    public void stockUpdate(String stockSym, double price) throws RemoteException {
        
        // do update
        if (stockPrices.containsKey(stockSym)) {
            
            stockPrices.put(stockSym, price);
            System.out.println("Successfully update price for " + stockSym);
            
        } else {
            
            System.out.println("Cannot find the stock of " + stockSym);
            
        }
        
        // notify all the users interested in the stock
        if (stocks.containsKey(stockSym)) {
            
            ArrayList<String> userList = stocks.get(stockSym);
            
            Iterator userIterator = userList.iterator();
            
            while (userIterator.hasNext()) {
                
                String userName = (String)userIterator.next();
                
                if (users.containsKey(userName)) {
                    
                    // call the notify method of the remote client callBack object to notify the user about the changed price
                    users.get(userName).notify(stockSym, price); 
                    
                } else {
                    
                    System.err.println("Unregistered user existed.");
                    
                }
                
            }
        } else {
            
            System.err.println("Inexisted Stock");
            
        }
    }

    /**
     * registerCallBack - register the Notifiable object with the corresponding user for accepting price update
     * 
     * @param remoteClient the Notifiable object to be associated with a user
     * @param user the user name to be associated
     * 
     * @throws RemoteException 
     */
    @Override
    public void registerCallBack(Notifiable remoteClient, String user) throws RemoteException {
        
        if (users.containsKey(user)) {
            
            users.put(user, remoteClient);
            
        } else {
            
            users.put(user, remoteClient);
            
        }
        
    }

    /**
     *  deRegisterCallBack - remove the Remote Notifiable object from the user list to deregister user from the stock
     * 
     * @param user user name of the related Notifiable object to be removed
     * 
     * @throws RemoteException 
     */
    @Override
    public void deRegisterCallBack(String user) throws RemoteException {

        if (users.containsKey(user)) {
            
            users.get(user).exit();
            users.remove(user);
            
        } else {
            
            System.err.println("User is not existed");
            
        }
    }
    
}
