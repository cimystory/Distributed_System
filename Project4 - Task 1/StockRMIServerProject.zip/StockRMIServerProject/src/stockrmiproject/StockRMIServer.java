package stockrmiproject;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * RMI server class
 * 
 * @author Gao
 */
public class StockRMIServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try {
            
            // create a servant
            StockRMI servant = new StockRMIServant();
            // create the registry
            LocateRegistry.createRegistry(1099);
            // name binding
            Naming.rebind(String.format("//127.0.0.1:%d/Stock", 1099), servant); 
            
            System.out.println("Stock server ready");
            
        } catch (RemoteException ex) {
            
            Logger.getLogger(StockRMIServer.class.getName()).log(Level.SEVERE, null, ex);
            
        } catch (MalformedURLException ex) {
            
            Logger.getLogger(StockRMIServer.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
    }
    
}
