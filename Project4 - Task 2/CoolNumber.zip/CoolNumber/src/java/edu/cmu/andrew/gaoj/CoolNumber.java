package edu.cmu.andrew.gaoj;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * CoolNumber Servlet implementing the CoolNumber web service for the app
 * @author Gao
 */
@WebServlet(name = "CoolNumber", urlPatterns = {"/CoolNumber/*"})
public class CoolNumber extends HttpServlet {
    
    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
    }

    // This servlet will reply to HTTP GET requests via this doGet method
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String output = "";
        PrintWriter out = response.getWriter();
        
        String requestString = request.getPathInfo();
        System.out.println("Request String: " + requestString);
        
        // the query string for the api
        String queryString = "http://numbersapi.com/";

        if (requestString != null) {
            String[] params = requestString.split("/"); // /23/math
            System.out.println("Params[1]: " + params[1]);
            System.out.println("Params[2]: " + params[2]);
            
            /*
             * Generating the corresponding query string
             */
            if (params[1] != null) {
                
                if (params[1].equals("random")) {
                    
                    queryString += "random/" + params[2];  

                } else {
                    
                    queryString += params[1] + "/" + params[2];

                }
            } 
               
            System.out.println("Query String： " + queryString);

            try {
                
                // generate HTTPURL
                URL url = new URL(queryString);
                // create HTTP connection
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                
                try ( 
                    // Read all the text returned by the server
                    BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    String str;
                    // Read each line of "in" until done, adding each to "response"
                    while ((str = in.readLine()) != null) {
                        // str is one line of text readLine() strips newline characters
                        output += str;
                    }
                }

                output = generateXML(output);
                out.append(output);
                out.flush();
                System.out.println("Output: " + output);
                
            } catch (IOException e) {
                System.out.println("Eeek, an exception: " + e.getMessage());
            }
            
        } else {
                
                output = "Please give the right input."; 
                out.append(output);
                out.flush();              
                
        }
        
    }
    
    /**
     * generate XML response for the client side
     * 
     * @param output plain text output String
     * @return the XML formatted String for the client side
     */
    public String generateXML(String output) {
        
        String result = "";
        
        try {
            
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            // root elements
            Element rootElement = doc.createElement("CoolNumber");
            doc.appendChild(rootElement);

            // spyOperation elements
            Element meaning = doc.createElement("Meaning");
            meaning.appendChild(doc.createTextNode(output));
            rootElement.appendChild(meaning);
            
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            result = writer.getBuffer().toString(); 
        
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(CoolNumber.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(CoolNumber.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(CoolNumber.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }
}
