package gaoj.andrew.cmu.edu.coolnumber;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class CoolNumber extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final CoolNumber coolNumber = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button) findViewById(R.id.submitButton);

        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View viewParam) {
                String type = ((EditText) findViewById(R.id.typeText)).getText().toString(); // get the input type parameter
                String number = ((EditText) findViewById(R.id.numberText)).getText().toString(); // get the input number parameter
                String isRandom; // get whether it's random

                if (((CheckBox) findViewById(R.id.random)).isChecked()) {
                    isRandom = "true";
                } else {
                    isRandom = "false";
                }

                // call the function to get meaning
                GetNumberMeaning getNumberMeaning = new GetNumberMeaning();
                getNumberMeaning.search(type, number, isRandom, coolNumber); // Done asynchronously in another thread.  It calls ip.pictureReady() in this thread when complete.
            }
        });


    }

    /**
     *
     * This is called by the GetNumberMeaning object when the meaning is ready.
     * This allows for passing back the meaning for updating the EditText
     *
     * @param meaning the output meaning
     */
    public void numberMeaningReady(String meaning) {

        EditText meaningText = (EditText) findViewById(R.id.givenNumberResult);

        if (meaning != null) {
            meaningText.setText(meaning);
            meaningText.setVisibility(View.VISIBLE);
        } else {
            meaningText.setText("Cannot find the meaning.");
            meaningText.setVisibility(View.VISIBLE);
        }
    }

}
