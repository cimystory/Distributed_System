package gaoj.andrew.cmu.edu.coolnumber;

import android.os.AsyncTask;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 *
 * This class provides capabilities to search for a special meaning for a number on http://numbersapi.com given a number and type.
 * The method "search" is the entry to the class.
 * Network operations cannot be done from the UI thread, therefore this class makes use of an AsyncTask inner class that will do the network
 * operations in a separate worker thread.  However, any UI updates should be done in the UI thread so avoid any synchronization problems.
 * onPostExecution runs in the UI thread, and it calls the EditText numberMeaningReady method to do the update.
 *
 * Created by Gao on 9/11/2015.
 */
public class GetNumberMeaning {

    CoolNumber coolNumber = null;

    /**
     * search is the public getNumberMeaning method. Its arguments are the search term, and the CoolNumber object that called it.
     * This provides a callback path such that the numberMeaningReady method in that object is called when the meaning is available from the search.
     */
    public void search(String type, String number, String isRandom, CoolNumber coolNumber) {

        this.coolNumber = coolNumber;
        new AsyncNumberSearch().execute(type, number, isRandom);

    }

    /**
	 * AsyncTask provides a simple way to use a thread separate from the UI thread in which to do network operations.
	 * doInBackground is run in the helper thread.
	 * onPostExecute is run in the UI thread, allowing for safe UI updates.
	 */
    private class AsyncNumberSearch extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            return search(params[0],params[1], params[2]);
        }

        @Override
        protected void onPostExecute(String result) {
            coolNumber.numberMeaningReady(result);
        }

        /*
        * Search http://numbersapi.com for the searchTerm argument, and return a String that can be put in an EditText
        */
        private String search(String type, String number, String isRandom){

            String response = "";
            String urlString = "";
            HttpURLConnection conn;
            URL url;
            int status;

            if (isRandom.equals("false")) {
                urlString += "https://dry-citadel-3659.herokuapp.com/CoolNumber/" + number + "/" + type;

            } else {
                urlString += "https://dry-citadel-3659.herokuapp.com/CoolNumber/random" + "/" + type;
            }

            System.out.println("Url string: " + urlString);
            try {
                url = new URL(urlString);
                conn = (HttpURLConnection) url.openConnection();

                conn.setRequestMethod("GET");
                // tell the server what format we want back
                conn.setRequestProperty("Accept", "text/plain");

                // wait for response
                status = conn.getResponseCode();
                System.out.println("response code: " + status);

                // If things went poorly, get the error status and message
                if (status != 200) {
                    // not using msg
                    String msg = conn.getResponseMessage();
                    return conn.getResponseCode() + " " + msg;
                }

                // get the response
                String output;
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

                while ((output = br.readLine()) != null) {
                    response += output + "\n";
                }

                response = XMLPaser(response);
                System.out.println("response: " + response);

                conn.disconnect();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return response;

        }

        /**
         * Parse the XML formatted response
         *
         * @param xmlString XML formatted response String
         * @return the plain text meaning to be displayed
         */
        private String XMLPaser (String xmlString) {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            Document doc;

            String meaning = "";

            try {
                builder = factory.newDocumentBuilder();
                doc = builder.parse(new InputSource(new StringReader(xmlString)));
                NodeList nl = doc.getElementsByTagName("CoolNumber");

                if (nl.getLength() == 0) {
                    return null; // no meaning found

                } else {
                    Node node = nl.item(0);
                    Element element = (Element) node;

                    meaning = element.getElementsByTagName("Meaning").item(0).getTextContent();
                    return meaning;
                }
            } catch(Exception e) {
                e.printStackTrace();
            }

            return meaning;

        }
    }
}
